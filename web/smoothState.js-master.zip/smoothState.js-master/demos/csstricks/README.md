# Demo: CSS Tricks with smoothState.js

Alternate demo showing caching, prefetching, and animating transitions with [smoothState.js](https://github.com/miguel-perez/smoothState.js).

You can [view the demo here](https://rawgit.com/miguel-perez/smoothState.js/master/demos/csstricks/index.html).