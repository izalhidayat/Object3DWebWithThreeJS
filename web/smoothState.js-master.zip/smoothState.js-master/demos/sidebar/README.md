# Demo: CSS Tricks with smoothState.js

Alternate demo demonstrates sidebar navigation with [smoothState.js](https://github.com/miguel-perez/smoothState.js).

You can [view the demo here](https://rawgit.com/miguel-perez/smoothState.js/master/demos/sidevar/index.html).